package cnc.aplicativo.cncplottersender

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.MotionEvent
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.Charset
import java.util.*
import java.util.concurrent.CountDownLatch
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import kotlin.collections.LinkedHashMap
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    // ---------------------------
    // CONFIGURABLE CONSTANTS
    // ---------------------------
    private val MENU_POP_SCALE = 1.06f
    private val MENU_ANIM_DURATION = 280L
    private val MENU_STAGGER = 80L
    private val MENU_ITEM_OFFSET_DP = 8f

    private val FILE_SEND_MAX_LINES = 200_000   // safety limit

    // Tamanho máximo de linha que pode ser enviada e recebida pelo arduino
    private val MAX_LINE_BUFFER = 120

    // filtro de comandos válidos para a CNC
    private val ALLOWED_CMDS = setOf('M','S','Z','C','U','D','N','X','Y')

    // prefs para guardar comandos configurados
    private lateinit var prefs: SharedPreferences
    private val PREFS_NAME = "cnc_prefs"
    private val KEY_BTN_LEFT  = "btn_left_cmd"
    private val KEY_BTN_RIGHT = "btn_right_cmd"
    private val KEY_BTN_UP    = "btn_up_cmd"
    private val KEY_BTN_DOWN  = "btn_down_cmd"

    // prefs para passos (mm)
    private val KEY_STEP_LEFT  = "btn_left_step"
    private val KEY_STEP_RIGHT = "btn_right_step"
    private val KEY_STEP_UP    = "btn_up_step"
    private val KEY_STEP_DOWN  = "btn_down_step"

    // valores padrão (mm)
    private val DEFAULT_STEP_LEFT  = 10f
    private val DEFAULT_STEP_RIGHT = 10f
    private val DEFAULT_STEP_UP    = 10f
    private val DEFAULT_STEP_DOWN  = 10f

    // posição mantida pelo app (mm)
    @Volatile private var currentX = 0.0
    @Volatile private var currentY = 0.0

    private lateinit var penUpButton: ImageView
    private lateinit var penDownButton: ImageView

    // valores padrão
    private val DEFAULT_LEFT  = "X0"
    private val DEFAULT_RIGHT = "X100"
    private val DEFAULT_UP    = "Y100"
    private val DEFAULT_DOWN  = "Y0"

    // ---------------------------
    // Views
    // ---------------------------
    private lateinit var leftButton: ImageView
    private lateinit var rightButton: ImageView
    private lateinit var upButton: ImageView
    private lateinit var downButton: ImageView
    private lateinit var resetButton: ImageView
    private lateinit var confirmButton: ImageView
    private lateinit var notButton: ImageView
    private lateinit var offButton: ImageView
    private lateinit var playButton: ImageView
    private lateinit var pauseButton: ImageView

    private lateinit var configsButton: ImageView
    private lateinit var bluetoothButton: ImageView
    private lateinit var arquivoButton: ImageView
    private lateinit var menuContainer: LinearLayout
    private lateinit var menuOverlay: View
    private var isMenuOpen = false
    private val menuItems: MutableList<View> = ArrayList()

    private lateinit var terminalScroll: ScrollView
    private lateinit var terminalContent: TextView
    private lateinit var terminalTitle: TextView
    private lateinit var fileProgress: TextView
    private lateinit var fileProgressBar: ProgressBar

    private lateinit var inputBox: EditText

    private var etaTextView: TextView? = null

    // ---------------------------
    // Bluetooth
    // ---------------------------
    private val bluetoothManager by lazy { getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager }
    private val bluetoothAdapter: BluetoothAdapter? by lazy { bluetoothManager.adapter }
    private var bleScanner: BluetoothLeScanner? = null
    private var isScanning = false
    private val handler = Handler(Looper.getMainLooper())

    private val discoveredDevices = LinkedHashMap<String, BluetoothDevice>()
    private var bluetoothGatt: BluetoothGatt? = null
    private var commCharacteristic: BluetoothGattCharacteristic? = null

    private val SERVICE_UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
    private val CHAR_UUID    = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")
    private val CLIENT_CHAR_CFG = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private val colorSent = Color.parseColor("#4CAF50")   // verde
    private val colorReceived = Color.parseColor("#2196F3") // azul
    private val colorInfo = Color.parseColor("#FFFFFF")   // branco

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val ok = perms.entries.all { it.value }
        if (ok) {
            appendInfo("Permissões concedidas.")
            startBleScanWithChecks()
        } else {
            appendInfo("Permissões necessárias não concedidas.")
        }
    }

    private val enableBtLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (bluetoothAdapter?.isEnabled == true) {
            appendInfo("Bluetooth ativado.")
            startBleScanWithChecks()
        } else {
            appendInfo("Bluetooth não ativado.")
        }
    }

    private val openDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) {
            appendInfo("Seleção de arquivo cancelada.")
            return@registerForActivityResult
        }
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) { /* ignore if not persistable */ }

        handlePickedFile(uri)
    }

    @Volatile private var isSendingFile = false
    @Volatile private var isPaused = false

    private val pauseLock = Object()
    private var pendingFileUri: Uri? = null
    private var pendingTotalLines: Int = 0
    private var pendingLineEstimates: MutableList<Long> = ArrayList()

    @Volatile private var sentLinesCount = 0
    @Volatile private var specialAwaitingLatch: CountDownLatch? = null
    @Volatile private var sendAwaitingLatch: CountDownLatch? = null
    @Volatile private var resetRequestedDuringSend = false

    private val origTrans = HashMap<View, Pair<Float, Float>>()

    private val pendingLinesQueue: ArrayDeque<String> = ArrayDeque()
    private val pendingEstimatesQueue: ArrayDeque<Long> = ArrayDeque()      // estimate per pending line (ms)

    @Volatile private var totalRemainingMs: Long = 0L

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        bindViews()
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        loadStepSizes()
        loadButtonCommands()
        createEtaTextView()

        terminalContent.post {
            captureOriginalTranslations()
            prepareInitialEntranceState()
            startEntranceAnimation()
        }

        setupMenuInitialState()
        setupListeners()
        updateFileProgressUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopScan()
        closeGatt()
    }

    private fun bindViews() {
        leftButton = findViewById(R.id.LeftButton)
        rightButton = findViewById(R.id.RightButton)
        upButton = findViewById(R.id.UpButton)
        downButton = findViewById(R.id.DownButton)
        resetButton = findViewById(R.id.ResetButton)
        confirmButton = findViewById(R.id.ConfirmButton)
        notButton = findViewById(R.id.Not_Button)
        offButton = findViewById(R.id.OffButton)
        playButton = findViewById(R.id.PlayButton)
        pauseButton = findViewById(R.id.PauseButton)
        penUpButton = findViewById(R.id.PenUp)
        penDownButton = findViewById(R.id.PenDown)


        configsButton = findViewById(R.id.ConfigsButton)
        bluetoothButton = findViewById(R.id.BluetoothButton)
        arquivoButton = findViewById(R.id.Arquivo)
        menuContainer = findViewById(R.id.menuContainer)
        menuOverlay = findViewById(R.id.menuOverlay)

        terminalScroll = findViewById(R.id.terminal)
        terminalContent = findViewById(R.id.terminalContent)
        terminalTitle = findViewById(R.id.terminalTitle)
        fileProgress = findViewById(R.id.fileProgress)
        fileProgressBar = findViewById(R.id.fileProgressBar)

        inputBox = findViewById(R.id.inputBox)

        menuItems.clear()
        menuItems.add(bluetoothButton)
        menuItems.add(arquivoButton)
    }

    private fun loadStepSizes() {

        val editor = prefs.edit()
        if (!prefs.contains(KEY_STEP_LEFT))  editor.putFloat(KEY_STEP_LEFT, DEFAULT_STEP_LEFT)
        if (!prefs.contains(KEY_STEP_RIGHT)) editor.putFloat(KEY_STEP_RIGHT, DEFAULT_STEP_RIGHT)
        if (!prefs.contains(KEY_STEP_UP))    editor.putFloat(KEY_STEP_UP, DEFAULT_STEP_UP)
        if (!prefs.contains(KEY_STEP_DOWN))  editor.putFloat(KEY_STEP_DOWN, DEFAULT_STEP_DOWN)
        editor.apply()
    }


    private fun createEtaTextView() {
        val root = findViewById<View>(android.R.id.content) as View
        val parent = (root as? ViewGroup) ?: return
        etaTextView = TextView(this).apply {
            text = ""
            textSize = 14f
            setTextColor(Color.parseColor("#FFEEEEEE"))
            setBackgroundColor(Color.parseColor("#22000000"))
            setPadding(12, 6, 12, 6)
            visibility = View.GONE
        }
        parent.addView(etaTextView)
    }

    private fun positionEtaAboveControls() {
        etaTextView?.let { etv ->
            val left = minOf(resetButton.x, playButton.x, offButton.x)
            val right = maxOf(resetButton.x + resetButton.width, playButton.x + playButton.width, offButton.x + offButton.width)
            val centerX = (left + right) / 2f
            val yAbove = minOf(resetButton.y, playButton.y, offButton.y) - dpToPx(44f)
            etv.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
            val w = etv.measuredWidth
            etv.x = centerX - w / 2f
            etv.y = if (yAbove > 8f) yAbove else 8f
        }
    }

    private fun captureOriginalTranslations() {
        val buttons = listOf(leftButton, rightButton, upButton, downButton, resetButton, penUpButton, penDownButton)
        buttons.forEach { v ->
            origTrans[v] = Pair(v.translationX, v.translationY)
        }
    }

    private fun prepareInitialEntranceState() {
        val deltaResetX = playButton.x - resetButton.x
        val deltaResetY = playButton.y - resetButton.y

        resetButton.translationX = deltaResetX
        resetButton.translationY = deltaResetY

        val startX = playButton.x
        val startY = playButton.y

        val motionButtons = listOf(leftButton, rightButton, upButton, downButton, penUpButton, penDownButton)
        motionButtons.forEach { v ->
            v.alpha = 0f
            val dx = startX - v.x
            val dy = startY - v.y
            v.translationX = dx
            v.translationY = dy
        }

        positionEtaAboveControls()
    }

    private fun startEntranceAnimation() {
        resetButton.animate()
            .translationX(0f)
            .translationY(0f)
            .setDuration(380)
            .setInterpolator(OvershootInterpolator(1.0f))
            .withEndAction {
                var delay = 0L
                val buttons = listOf(leftButton, upButton, downButton, rightButton, penUpButton, penDownButton)
                buttons.forEach { v ->
                    v.animate()
                        .translationX(0f)
                        .translationY(0f)
                        .alpha(1f)
                        .setStartDelay(delay)
                        .setDuration(260)
                        .setInterpolator(OvershootInterpolator(1.1f))
                        .start()
                    delay += 70L
                }
            }
            .start()
    }

    private fun setupMenuInitialState() {
        isMenuOpen = false
        menuContainer.visibility = View.GONE
        menuOverlay.visibility = View.GONE

        val offset = -dpToPx(MENU_ITEM_OFFSET_DP)
        menuItems.forEach { v ->
            v.alpha = 0f
            v.scaleX = 0.95f
            v.scaleY = 0.95f
            v.translationY = offset
            v.isClickable = false
            v.isFocusable = false
        }
        configsButton.rotation = 0f

        menuOverlay.setOnClickListener { if (isMenuOpen) closeMenu() }

        menuContainer.bringToFront()
        configsButton.bringToFront()
    }

    private fun setupListeners() {
        setupMoveButton(leftButton, KEY_STEP_LEFT, DEFAULT_STEP_LEFT, 'X', -1)
        setupMoveButton(rightButton, KEY_STEP_RIGHT, DEFAULT_STEP_RIGHT, 'X', +1)
        setupMoveButton(upButton, KEY_STEP_UP, DEFAULT_STEP_UP, 'Y', +1)
        setupMoveButton(downButton, KEY_STEP_DOWN, DEFAULT_STEP_DOWN, 'Y', -1)

        resetButton.setOnClickListener {
            if (!isSendingFile) {
                appendSent("Z1 X0 Y0")
                sendStringToBle("Z1 X0 Y0")
                currentX = 0.0
                currentY = 0.0
            } else {
                resetRequestedDuringSend = true
                pauseSending()
                appendInfo("Reset solicitado")
            }
        }

        playButton.setOnClickListener {
            if (!isSendingFile && pendingFileUri != null) {
                appendInfo("Iniciando calibração e cálculo de ETA (Play)...")
                runOnUiThread { animateHideForSending() }
                Thread { startCalibrationAndEstimateThenSend() }.start()
            } else if (isSendingFile && isPaused) {
                appendInfo("Retomando envio (Play).")
                runOnUiThread { animateHideForSending() }
                resumeSending()
            } else {
            }
        }

        pauseButton.setOnClickListener {
            if (isSendingFile) {
                appendInfo("Pausando envio (Pause).")
                pauseSending()
                runOnUiThread { animateShowDuringPause() }
            } else {
            }
        }

        offButton.setOnClickListener {
            if (isSendingFile) {
                appendInfo("Cancelando envio (Off).")
                cancelSending()
                runOnUiThread { animateShowAfterFinish() }
            } else {
            }
        }

        confirmButton.setOnClickListener {
            if (isSendingFile && !isPaused) {
                appendInfo("Envio de arquivo em progresso — ação desabilitada.")
                return@setOnClickListener
            }
            val text = inputBox.text.toString().trim()
            if (text.isNotEmpty()) {
                val filtered = filterLineForArduino(text)
                if (filtered == null) {
                    appendInfo("Linha não contém comandos válidos para a CNC — não enviada.")
                } else {
                    appendSent(filtered)
                    sendStringToBle(filtered)
                    inputBox.setText("")
                    hideKeyboard()
                }
            } else {
                appendInfo("Escreva algo para enviar")
            }
        }

        notButton.setOnClickListener {
            runOnUiThread {
                terminalContent.text = ""
                terminalScroll.post { terminalScroll.fullScroll(View.FOCUS_UP) }
            }
        }

        configsButton.setOnClickListener { toggleMenu() }

        bluetoothButton.setOnClickListener {
            if (isSendingFile && !isPaused) {
                appendInfo("Envio de arquivo em progresso — Bluetooth temporariamente desabilitado.")
                return@setOnClickListener
            }
            onBluetoothButtonPressed()
        }

        arquivoButton.setOnClickListener {
            if (isSendingFile && !isPaused) {
                appendInfo("Envio de arquivo já em andamento.")
                return@setOnClickListener
            }
            closeMenu()
            openFilePickerForGcode()
        }

        // PenUp / PenDown buttons: clique curto envia Z1 / Z0; não possuem configuração longa.
        penUpButton.setOnClickListener {
            if (isSendingFile && !isPaused) {
                appendInfo("Envio de arquivo em andamento — botão temporariamente desabilitado.")
            } else {
                appendSent("Z1")
                sendStringToBle("Z1")
            }
        }

        penDownButton.setOnClickListener {
            if (isSendingFile && !isPaused) {
                appendInfo("Envio de arquivo em andamento — botão temporariamente desabilitado.")
            } else {
                appendSent("Z0")
                sendStringToBle("Z0")
            }
        }
    }

    private fun setupMoveButton(
        button: ImageView,
        prefKeyStep: String,
        defaultStep: Float,
        axis: Char,         // 'X' ou 'Y'
        dir: Int            // +1 para aumentar (Right/Up), -1 para diminuir (Left/Down)
    ) {
        val handler = Handler(Looper.getMainLooper())
        var longPressed = false
        val longPressRunnable = Runnable {
            longPressed = true
            runOnUiThread { showStepConfigDialog(prefKeyStep, defaultStep) }
        }

        button.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    longPressed = false
                    handler.postDelayed(longPressRunnable, 1000) // 1s long-press
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPressRunnable)
                    if (!longPressed) {
                        // Short click -> drive position
                        if (isSendingFile && !isPaused) {
                            appendInfo("Envio de arquivo em andamento — botão temporariamente desabilitado.")
                        } else {
                            val step = prefs.getFloat(prefKeyStep, defaultStep)
                            // atualiza posição
                            if (axis == 'X') {
                                currentX = (currentX + dir * step).coerceAtLeast(-1e6) // bounds opcionais
                                val cmd = formatCoordCommand('X', currentX)
                                appendSent(cmd)
                                sendStringToBle(cmd)
                            } else {
                                currentY = (currentY + dir * step).coerceAtLeast(-1e6)
                                val cmd = formatCoordCommand('Y', currentY)
                                appendSent(cmd)
                                sendStringToBle(cmd)
                            }
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPressRunnable)
                    true
                }
                else -> false
            }
        }
    }

    private fun loadButtonCommands() {
        // garante que existam comandos padrão salvos
        val editor = prefs.edit()
        if (!prefs.contains(KEY_BTN_LEFT))  editor.putString(KEY_BTN_LEFT, DEFAULT_LEFT)
        if (!prefs.contains(KEY_BTN_RIGHT)) editor.putString(KEY_BTN_RIGHT, DEFAULT_RIGHT)
        if (!prefs.contains(KEY_BTN_UP))    editor.putString(KEY_BTN_UP, DEFAULT_UP)
        if (!prefs.contains(KEY_BTN_DOWN))  editor.putString(KEY_BTN_DOWN, DEFAULT_DOWN)
        editor.apply()
    }

    private fun showStepConfigDialog(prefKeyStep: String, defaultStep: Float) {
        val current = prefs.getFloat(prefKeyStep, defaultStep)
        val edit = EditText(this)
        edit.setText(current.toString())
        edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        edit.setSelectAllOnFocus(true)

        val builder = AlertDialog.Builder(this)
            .setTitle("Configurar passo (mm)")
            .setMessage("Defina o passo em mm que esse botão moverá (ex: 10 ou 2.5)")
            .setView(edit)
            .setPositiveButton("Salvar") { dialog, _ ->
                val txt = edit.text.toString().trim()
                try {
                    val v = txt.toFloat()
                    prefs.edit().putFloat(prefKeyStep, v).apply()
                    appendInfo("Passo salvo: $v mm")
                } catch (ex: Exception) {
                    Toast.makeText(this, "Valor inválido.", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

    private fun formatCoordCommand(axis: Char, value: Double): String {
        // remove ".0" desnecessário, usa '.' como separador
        val s = if (value == Math.round(value).toDouble()) {
            String.format(Locale.US, "%d", Math.round(value))
        } else {
            String.format(Locale.US, "%.3f", value).trimEnd('0').trimEnd('.')
        }
        return "${axis}${s}"
    }

    private fun showConfigDialog(prefKey: String, defaultCmd: String) {
        val current = prefs.getString(prefKey, defaultCmd) ?: defaultCmd
        val edit = EditText(this)
        edit.setText(current)
        edit.setSelectAllOnFocus(true)

        val builder = AlertDialog.Builder(this)
            .setTitle("Configurar botão")
            .setMessage("Defina o comando que esse botão envia (ex: X100)")
            .setView(edit)
            .setPositiveButton("Salvar") { dialog, _ ->
                val newCmd = edit.text.toString().trim()
                if (newCmd.isEmpty()) {
                    Toast.makeText(this, "Comando vazio — nada salvo.", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putString(prefKey, newCmd).apply()
                    appendInfo("Comando salvo: $newCmd")
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }

        builder.show()
    }

    // -----------------------
    // menu animation logic
    // -----------------------
    private fun toggleMenu() {
        if (!isMenuOpen) openMenu() else closeMenu()
    }

    private fun openMenu() {
        isMenuOpen = true
        menuContainer.visibility = View.VISIBLE
        menuOverlay.visibility = View.VISIBLE
        menuOverlay.isClickable = true
        menuContainer.bringToFront()
        configsButton.bringToFront()

        configsButton.animate()
            .rotation(45f)
            .setDuration(MENU_ANIM_DURATION)
            .setInterpolator(OvershootInterpolator(1.0f))
            .start()

        var delay = 0L
        menuItems.forEachIndexed { _, v ->
            v.isClickable = false
            v.isFocusable = false
            v.alpha = 0f
            v.scaleX = 0.95f
            v.scaleY = 0.95f
            v.translationY = -dpToPx(MENU_ITEM_OFFSET_DP)
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .scaleX(MENU_POP_SCALE)
                .scaleY(MENU_POP_SCALE)
                .setStartDelay(delay)
                .setDuration(MENU_ANIM_DURATION)
                .setInterpolator(OvershootInterpolator(1.2f))
                .withEndAction {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    v.isClickable = true
                    v.isFocusable = true
                }
                .start()
            delay += MENU_STAGGER
        }
    }

    private fun closeMenu() {
        isMenuOpen = false
        menuOverlay.isClickable = false

        configsButton.animate()
            .rotation(0f)
            .setDuration(MENU_ANIM_DURATION)
            .setInterpolator(OvershootInterpolator(1.0f))
            .start()

        var delay = 0L
        menuItems.asReversed().forEach { v ->
            v.isClickable = false
            v.isFocusable = false
            v.animate()
                .alpha(0f)
                .translationY(-dpToPx(MENU_ITEM_OFFSET_DP))
                .scaleX(0.95f)
                .scaleY(0.95f)
                .setStartDelay(delay)
                .setDuration(MENU_ANIM_DURATION)
                .setInterpolator(OvershootInterpolator(1.0f))
                .withEndAction {
                    if (v == menuItems.first()) {
                        menuContainer.visibility = View.GONE
                        menuOverlay.visibility = View.GONE
                    }
                }
                .start()
            delay += MENU_STAGGER
        }

        menuContainer.bringToFront()
        configsButton.bringToFront()
    }

    private fun dpToPx(dp: Float): Float {
        return dp * resources.displayMetrics.density
    }

    // -----------------------
    // FILE PICKER & SENDING
    // -----------------------
    private fun openFilePickerForGcode() {
        try {
            openDocumentLauncher.launch(arrayOf("*/*"))
            appendInfo("Abrindo seletor de arquivos...")
        } catch (e: Exception) {
            appendInfo("Erro ao abrir seletor de arquivos: ${e.message}")
        }
    }

    private fun handlePickedFile(uri: Uri) {
        val name = queryFileName(uri)
        appendInfo("Arquivo selecionado: ${name ?: uri.lastPathSegment}")

        // Count non-empty lines (trimmed).
        var counted = 0
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        if (line?.trim()?.isNotEmpty() == true) counted++
                        if (counted > FILE_SEND_MAX_LINES) break
                    }
                }
            }
        } catch (ex: Exception) {
            appendInfo("Erro ao ler arquivo para contagem: ${ex.message}")
            return
        }

        if (counted == 0) {
            appendInfo("Arquivo não contém linhas de G-code detectáveis (não-vazias).")
            return
        }

        pendingFileUri = uri
        pendingTotalLines = counted
        sentLinesCount = 0
        pendingLineEstimates.clear()
        runOnUiThread { updateFileProgressUi() }

        appendInfo("Linhas detectadas no arquivo: $pendingTotalLines")
        appendInfo("Pronto — pressione PLAY para iniciar calibração, cálculo e envio.")
    }

    private fun queryFileName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // -----------------------
    // Calibration + Estimate + Send sequence
    // -----------------------
    private fun startCalibrationAndEstimateThenSend() {
        val uri = pendingFileUri
        if (uri == null) {
            appendInfo("Nenhum arquivo pendente para envio.")
            return
        }

        val gatt = bluetoothGatt
        val ch = commCharacteristic
        if (gatt == null || ch == null) {
            appendInfo("Não conectado / característica indisponível. Não foi possível calibrar/enviar.")
            runOnUiThread { animateShowAfterFinish() }
            return
        }

        // Reset inicial
        appendInfo("Resetando posições iniciais: enviando 'Z1 X0 Y0' ...")
        val tResetInit = measureCommandTime("Z1 X0 Y0")
        if (tResetInit <= 0L) {
            appendInfo("Reset inicial não respondeu OK. Continuando mesmo assim.")
        } else {
            appendInfo("Reset inicial respondido em ${tResetInit} ms")
        }

        appendInfo("Iniciando calibração: enviando Z0, depois Z1, X10, Y10 (aguardando respostas)...")

        // Teste Z0
        val tZ = measureCommandTime("Z0")
        if (tZ <= 0L) {
            appendInfo("Calibração Z0 falhou. Abortando.")
            runOnUiThread { animateShowAfterFinish() }
            return
        }
        appendInfo("Medição Z0: ${tZ} ms")

        // Subir caneta após Z0
        val tZ1 = measureCommandTime("Z1")
        if (tZ1 <= 0L) {
            appendInfo("Z1 (subida pós Z0) não respondeu OK. Continuando mesmo assim.")
        } else {
            appendInfo("Subida Z1 após teste Z0 respondida em ${tZ1} ms")
        }

        // Teste X10
        val tX10 = measureCommandTime("X10")
        if (tX10 <= 0L) {
            appendInfo("Calibração X10 falhou. Abortando.")
            runOnUiThread { animateShowAfterFinish() }
            return
        }
        appendInfo("Medição X10: ${tX10} ms")

        // Teste Y10
        val tY10 = measureCommandTime("Y10")
        if (tY10 <= 0L) {
            appendInfo("Calibração Y10 falhou. Abortando.")
            runOnUiThread { animateShowAfterFinish() }
            return
        }
        appendInfo("Medição Y10: ${tY10} ms")

        // Reset final
        appendInfo("Resetando posições finais: enviando 'Z1 X0 Y0' ...")
        val tResetFinal = measureCommandTime("Z1 X0 Y0")
        if (tResetFinal <= 0L) {
            appendInfo("Reset final não recebeu OK. Continuando mesmo assim.")
        } else {
            appendInfo("Reset final respondido em ${tResetFinal} ms")
        }

        // Conversão dos tempos
        val txPerMm = tX10.toDouble() / 10.0
        val tyPerMm = tY10.toDouble() / 10.0
        val tzPerMove = tZ.toDouble()

        appendInfo("Calculando estimativa para todo o arquivo (usarão tx=${String.format("%.2f", txPerMm)}ms/mm, ty=${String.format("%.2f", tyPerMm)}ms/mm, tz=${tzPerMove}ms por Z).")
        val perLineEstimates = computePerLineEstimates(uri, txPerMm, tyPerMm, tzPerMove)
        if (perLineEstimates == null || perLineEstimates.isEmpty()) {
            appendInfo("Falha ao calcular estimativas do arquivo. Abortando.")
            runOnUiThread { animateShowAfterFinish() }
            return
        }
        pendingLineEstimates = perLineEstimates.toMutableList()
        val totalMs = pendingLineEstimates.sum()
        appendInfo("Estimativa total calculada: ${formatMillis(totalMs)}")

        runOnUiThread {
            etaTextView?.visibility = View.VISIBLE
            etaTextView?.text = "ETA: ${formatMillis(totalMs)}"
            positionEtaAboveControls()
            fileProgressBar.max = pendingTotalLines
            fileProgressBar.progress = 0
        }

        appendInfo("Começando envio do arquivo...")
        startSendingPendingFileWithEstimates(uri)
    }

    // measure round-trip time for a command (blocking until ok)
    private fun measureCommandTime(cmd: String): Long {
        val gatt = bluetoothGatt
        val ch = commCharacteristic
        if (gatt == null || ch == null) {
            appendInfo("Não conectado para medição do comando $cmd")
            return -1L
        }
        val start = System.nanoTime()
        val latch = CountDownLatch(1)
        specialAwaitingLatch = latch
        try {
            val filtered = filterLineForArduino(cmd) ?: cmd // calibration commands are expected to be valid
            appendSent(filtered)
            ch.value = (filtered + "\n").toByteArray(Charset.forName("UTF-8"))
            ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            val okRequested = safeWriteCharacteristic(gatt, ch)
            if (!okRequested) {
                appendInfo("Falha ao solicitar escrita para comando de calibração: $cmd")
                specialAwaitingLatch = null
                return -1L
            }
            try {
                latch.await()
            } catch (ie: InterruptedException) {
                specialAwaitingLatch = null
                return -1L
            } finally {
                specialAwaitingLatch = null
            }
            val end = System.nanoTime()
            return ((end - start) / 1_000_000L) // ms
        } catch (se: SecurityException) {
            appendInfo("Permissão BLUETOOTH_CONNECT faltando ao medir $cmd: ${se.message}")
            specialAwaitingLatch = null
            return -1L
        } catch (ex: Exception) {
            appendInfo("Erro ao medir $cmd: ${ex.message}")
            specialAwaitingLatch = null
            return -1L
        }
    }

    @SuppressLint("MissingPermission")
    private fun safeWriteCharacteristic(gatt: BluetoothGatt?, ch: BluetoothGattCharacteristic?): Boolean {
        if (gatt == null || ch == null) return false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val has = ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            if (!has) {
                appendInfo("Permissão BLUETOOTH_CONNECT não concedida — solicitando permissões.")
                checkAndRequestPermissions()
                return false
            }
        }

        return try {
            val ok = gatt.writeCharacteristic(ch)
            if (!ok) appendInfo("gatt.writeCharacteristic retornou false.")
            ok
        } catch (se: SecurityException) {
            appendInfo("SecurityException ao escrever característica: ${se.message}")
            false
        } catch (ex: Exception) {
            appendInfo("Erro ao escrever característica: ${ex.message}")
            false
        }
    }

    private fun computePerLineEstimates(uri: Uri, txPerMm: Double, tyPerMm: Double, tzPerMove: Double): List<Long>? {
        val estimates = ArrayList<Long>()
        var prevX = 0.0
        var prevY = 0.0
        var prevZ = Double.NaN
        var counted = 0
        try {
            runOnUiThread {
                fileProgressBar.max = pendingTotalLines
                fileProgressBar.progress = 0
                fileProgressBar.visibility = View.VISIBLE
            }

            contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val raw = line ?: continue
                        val s = raw.trim()
                        if (s.isEmpty()) continue

                        counted++

                        val xVal = extractCoordinate(s, 'X')
                        val yVal = extractCoordinate(s, 'Y')
                        val zVal = extractCoordinate(s, 'Z')

                        val dx = if (xVal != null) abs(xVal - prevX) else 0.0
                        val dy = if (yVal != null) abs(yVal - prevY) else 0.0
                        val zChange = if (zVal != null && !prevZ.isNaN() && zVal != prevZ) true
                        else if (zVal != null && prevZ.isNaN()) true else false

                        val tXY = maxOf(dx * txPerMm, dy * tyPerMm)
                        val tZ = if (zVal != null && zChange) tzPerMove else 0.0

                        val lineMs = (tXY + tZ).toLong()
                        estimates.add(lineMs)

                        if (xVal != null) prevX = xVal
                        if (yVal != null) prevY = yVal
                        if (zVal != null) prevZ = zVal

                        runOnUiThread {
                            fileProgressBar.progress = counted
                            fileProgress.text = "Calculando: $counted / $pendingTotalLines linhas"
                        }
                    }
                }
            }
            runOnUiThread {
                fileProgressBar.progress = 0
                fileProgress.text = "Pronto para envio: $pendingTotalLines linhas"
            }
            return estimates
        } catch (ex: Exception) {
            appendInfo("Erro ao calcular estimativas: ${ex.message}")
            return null
        }
    }

    private fun extractCoordinate(line: String, axis: Char): Double? {
        try {
            val regex = Regex("${axis}([-+]?[0-9]*\\.?[0-9]+)", RegexOption.IGNORE_CASE)
            val m = regex.find(line)
            if (m != null) {
                val v = m.groupValues[1]
                return v.toDoubleOrNull()
            }
        } catch (_: Exception) { }
        return null
    }

    private fun startSendingPendingFileWithEstimates(uri: Uri) {
        Thread {
            sendFileLoopWithEstimates(uri)
        }.start()
    }

    // Sequential sending: send one line, wait for ok, then next
    @SuppressLint("MissingPermission")
    private fun sendFileLoopWithEstimates(uri: Uri) {
        val gatt = bluetoothGatt
        val ch = commCharacteristic
        if (gatt == null || ch == null) {
            appendInfo("Não conectado / característica indisponível. Não foi possível enviar arquivo.")
            runOnUiThread { animateShowAfterFinish() }
            return
        }

        if (pendingLineEstimates.isEmpty()) {
            appendInfo("Lista de estimativas vazia — abortando envio.")
            runOnUiThread { animateShowAfterFinish() }
            return
        }

        // load file lines (filtered) into queues so we keep lines <-> estimates aligned
        pendingLinesQueue.clear()
        pendingEstimatesQueue.clear()
        try {
            val linesList = ArrayList<String>()
            contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                    var raw: String?
                    while (reader.readLine().also { raw = it } != null) {
                        val r = raw?.trimEnd('\r')?.trim()
                        if (r.isNullOrEmpty()) continue
                        val filtered = filterLineForArduino(r)
                        if (filtered != null) linesList.add(filtered)
                    }
                }
            }

            if (linesList.isEmpty()) {
                appendInfo("Nenhuma linha válida para enviar.")
                runOnUiThread { animateShowAfterFinish() }
                return
            }

            val minCount = minOf(linesList.size, pendingLineEstimates.size)
            for (i in 0 until minCount) {
                pendingLinesQueue.addLast(linesList[i])
                pendingEstimatesQueue.addLast(pendingLineEstimates[i])
            }
        } catch (ex: Exception) {
            appendInfo("Erro ao ler arquivo para envio: ${ex.message}")
            runOnUiThread { animateShowAfterFinish() }
            return
        }

        totalRemainingMs = pendingEstimatesQueue.sum()
        sentLinesCount = 0

        isSendingFile = true
        isPaused = false
        resetRequestedDuringSend = false

        runOnUiThread {
            updateFileProgressUi()
            animateHideForSending()
            confirmButton.isEnabled = false
            configsButton.isEnabled = false
            positionEtaAboveControls()
            fileProgressBar.max = pendingTotalLines
            fileProgressBar.progress = 0
        }

        val etaUpdater = Timer()
        etaUpdater.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                runOnUiThread {
                    etaTextView?.visibility = if (isSendingFile) View.VISIBLE else View.GONE
                    if (isSendingFile) {
                        etaTextView?.text = "T est: ${formatMillis(maxOf(0L, totalRemainingMs))}"
                    }
                }
            }
        }, 0L, 1000L)

        var aborted = false

        try {
            while (pendingLinesQueue.isNotEmpty() && isSendingFile) {
                // respect pause
                synchronized(pauseLock) {
                    while (isPaused && isSendingFile && !resetRequestedDuringSend) {
                        try { pauseLock.wait() } catch (_: InterruptedException) {}
                    }
                }
                if (!isSendingFile) {
                    aborted = true
                    appendInfo("Envio cancelado.")
                    break
                }

                // send exactly one line and wait for OK
                val line = synchronized(pendingLinesQueue) { if (pendingLinesQueue.isNotEmpty()) pendingLinesQueue.removeFirst() else null }
                val est = synchronized(pendingEstimatesQueue) { if (pendingEstimatesQueue.isNotEmpty()) pendingEstimatesQueue.removeFirst() else 0L }

                if (line == null) break

                // send the line
                sendAwaitingLatch = CountDownLatch(1)
                try {
                    appendSent(line)
                    ch.value = (line + "\n").toByteArray(Charset.forName("UTF-8"))
                    ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                    val requested = safeWriteCharacteristic(gatt, ch)
                    if (!requested) {
                        appendInfo("Falha ao solicitar escrita para linha. Reinserindo na fila e abortando temporariamente.")
                        // put line back and attempt later
                        synchronized(pendingLinesQueue) { pendingLinesQueue.addFirst(line) }
                        synchronized(pendingEstimatesQueue) { pendingEstimatesQueue.addFirst(est) }
                        sendAwaitingLatch = null
                        // small sleep to avoid busy-loop
                        Thread.sleep(120)
                        continue
                    }

                    // Wait indefinitely for OK for this line
                    try {
                        sendAwaitingLatch?.await()
                    } catch (ie: InterruptedException) {
                        // ignore
                    } finally {
                        sendAwaitingLatch = null
                    }

                    // after OK of this line
                    sentLinesCount++
                    totalRemainingMs = (totalRemainingMs - est).coerceAtLeast(0L)

                    runOnUiThread {
                        fileProgressBar.progress = sentLinesCount
                        fileProgress.text = "${pendingTotalLines - sentLinesCount} de $pendingTotalLines linhas"
                        etaTextView?.text = "T est: ${formatMillis(maxOf(0L, totalRemainingMs))}"
                    }

                    // if reset requested during send, send Reset now (we already have OK for last line)
                    if (resetRequestedDuringSend) {
                        appendInfo("Executando Reset solicitado (será enviado após OK da linha).")
                        resetRequestedDuringSend = false
                        val latchReset = CountDownLatch(1)
                        specialAwaitingLatch = latchReset
                        try {
                            appendSent("Z1 X0 Y0")
                            ch.value = ("Z1 X0 Y0\n").toByteArray(Charset.forName("UTF-8"))
                            ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                            val req = safeWriteCharacteristic(gatt, ch)
                            if (!req) {
                                appendInfo("Falha ao solicitar escrita do Reset.")
                            } else {
                                try { latchReset.await() } catch (_: InterruptedException) {}
                            }
                        } catch (se: SecurityException) {
                            appendInfo("Falha ao escrever Reset (permissão BLUETOOTH_CONNECT): ${se.message}")
                        } catch (ex: Exception) {
                            appendInfo("Erro ao escrever Reset: ${ex.message}")
                        } finally {
                            specialAwaitingLatch = null
                        }
                        appendInfo("Reset finalizado — retomando envio.")
                    }
                } catch (se: SecurityException) {
                    appendInfo("Falha ao escrever (permissão BLUETOOTH_CONNECT): ${se.message}")
                    // try to requeue and abort
                    synchronized(pendingLinesQueue) { pendingLinesQueue.addFirst(line) }
                    synchronized(pendingEstimatesQueue) { pendingEstimatesQueue.addFirst(est) }
                    aborted = true
                    break
                } catch (ex: Exception) {
                    appendInfo("Erro ao enviar linha: ${ex.message}")
                    synchronized(pendingLinesQueue) { pendingLinesQueue.addFirst(line) }
                    synchronized(pendingEstimatesQueue) { pendingEstimatesQueue.addFirst(est) }
                    aborted = true
                    break
                }
            }
        } catch (ex: Exception) {
            appendInfo("Erro lendo/enviando arquivo: ${ex.message}")
            aborted = true
        } finally {
            etaUpdater.cancel()
            isSendingFile = false
            isPaused = false
            specialAwaitingLatch?.countDown()
            specialAwaitingLatch = null
            sendAwaitingLatch?.countDown()
            sendAwaitingLatch = null

            runOnUiThread {
                confirmButton.isEnabled = true
                configsButton.isEnabled = true
                etaTextView?.visibility = View.GONE
                animateShowAfterFinish()
            }

            if (!aborted) {
                appendInfo("Envio do arquivo finalizado. Linhas enviadas: $sentLinesCount / $pendingTotalLines")
            } else {
                appendInfo("Envio interrompido. Linhas enviadas: $sentLinesCount / $pendingTotalLines")
            }

            pendingFileUri = null
            pendingTotalLines = 0
            pendingLineEstimates.clear()
            sentLinesCount = 0
            pendingLinesQueue.clear()
            pendingEstimatesQueue.clear()
            totalRemainingMs = 0L
            runOnUiThread { updateFileProgressUi() }
        }
    }

    // Manual send (used by Confirm button) - uses safeWriteCharacteristic
    @SuppressLint("MissingPermission")
    private fun sendStringToBle(text: String) {
        val ch = commCharacteristic
        val gatt = bluetoothGatt
        if (gatt == null || ch == null) {
            appendInfo("Não conectado / característica indisponível. Não foi possível enviar.")
            return
        }

        try {
            val data = (text + "\n").toByteArray(Charset.forName("UTF-8"))
            ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            ch.value = data
            val ok = safeWriteCharacteristic(gatt, ch)
            if (!ok) {
                appendInfo("Falha ao solicitar escrita.")
            }
        } catch (ex: SecurityException) {
            appendInfo("Falha ao escrever (permissão BLUETOOTH_CONNECT): ${ex.message}")
        } catch (ex: Exception) {
            appendInfo("Erro ao escrever característica: ${ex.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        try {
            bluetoothGatt?.let { g ->
                try { g.disconnect() } catch (_: Exception) {}
                try { g.close() } catch (_: Exception) {}
            }
        } finally {
            bluetoothGatt = null
            commCharacteristic = null
        }
    }

    // -----------------------
    // Terminal helpers
    // -----------------------
    private fun appendColoredLine(text: String, color: Int) {
        val line = "$text\n"
        val span = SpannableStringBuilder(line)
        span.setSpan(ForegroundColorSpan(color), 0, line.length, 0)
        runOnUiThread {
            terminalContent.append(span)
            terminalScroll.post { terminalScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun appendInfo(text: String) {
        appendColoredLine(text, colorInfo)
    }

    private fun appendReceived(text: String) {
        appendColoredLine("Recebido: $text", colorReceived)
    }

    private fun appendSent(text: String) {
        appendColoredLine("Enviado: $text", colorSent)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(inputBox.windowToken, 0)
    }

    private fun formatMillis(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) String.format("%02d:%02d:%02d", hours, minutes, seconds)
        else String.format("%02d:%02d", minutes, seconds)
    }

    // -----------------------
    // Animations for directional buttons & reset
    // -----------------------
    private fun animateHideForSending() {
        runOnUiThread {
            val resetCenterX = resetButton.x + resetButton.width / 2f
            val resetCenterY = resetButton.y + resetButton.height / 2f

            var delay = 0L
            val buttons = listOf(leftButton, upButton, downButton, rightButton, penUpButton, penDownButton)
            buttons.forEach { v ->
                v.isClickable = false
                v.isFocusable = false

                val vxCenter = v.x + v.width / 2f
                val vyCenter = v.y + v.height / 2f
                val dx = resetCenterX - vxCenter
                val dy = resetCenterY - vyCenter

                v.animate()
                    .translationX(v.translationX + dx)
                    .translationY(v.translationY + dy)
                    .alpha(0f)
                    .setStartDelay(delay)
                    .setDuration(220)
                    .setInterpolator(OvershootInterpolator(0.8f))
                    .start()
                delay += 40L
            }

            val targetTx = (playButton.x - resetButton.x)
            val targetTy = (playButton.y - resetButton.y + dpToPx(6f))

            resetButton.animate()
                .setStartDelay(180)
                .translationX(targetTx)
                .translationY(targetTy)
                .setDuration(260)
                .setInterpolator(OvershootInterpolator(1.0f))
                .start()
        }
    }

    private fun animateShowAfterFinish() {
        runOnUiThread {
            val origReset = origTrans[resetButton] ?: Pair(0f, 0f)
            resetButton.animate()
                .translationX(origReset.first)
                .translationY(origReset.second)
                .setDuration(300)
                .setInterpolator(OvershootInterpolator(1.0f))
                .withEndAction {
                    var delay = 0L
                    val buttons = listOf(leftButton, upButton, downButton, rightButton, penUpButton, penDownButton)

                    buttons.forEach { v ->
                        v.isClickable = true
                        v.isFocusable = true
                        v.animate()
                            .translationX(0f)
                            .translationY(0f)
                            .alpha(1f)
                            .setStartDelay(delay)
                            .setDuration(260)
                            .setInterpolator(OvershootInterpolator(1.0f))
                            .start()
                        delay += 40L
                    }
                }
                .start()
        }
    }

    private fun animateShowDuringPause() {
        runOnUiThread {
            val origReset = origTrans[resetButton] ?: Pair(0f, 0f)
            resetButton.animate()
                .translationX(origReset.first)
                .translationY(origReset.second)
                .setDuration(200)
                .setInterpolator(OvershootInterpolator(1.0f))
                .start()

            var delay = 0L
            val buttons = listOf(leftButton, upButton, downButton, rightButton, penUpButton, penDownButton)

            buttons.forEach { v ->
                v.isClickable = true
                v.isFocusable = true
                v.animate()
                    .translationX(0f)
                    .translationY(0f)
                    .alpha(1f)
                    .setStartDelay(delay)
                    .setDuration(220)
                    .setInterpolator(OvershootInterpolator(1.0f))
                    .start()
                delay += 40L
            }
        }
    }

    // -----------------------
    // Called from GATT callback thread when device sends data
    // -----------------------
    private fun handleIncomingFromDevice(s: String) {
        appendReceived(s)
        // tenta extrair X e Y de respostas do dispositivo (ex.: "X12.3 Y4.5 ok")
        try {
            val rx = Regex("""X([-+]?[0-9]*\.?[0-9]+)""", RegexOption.IGNORE_CASE)
            val ry = Regex("""Y([-+]?[0-9]*\.?[0-9]+)""", RegexOption.IGNORE_CASE)
            val mx = rx.find(s)
            val my = ry.find(s)
            mx?.groupValues?.get(1)?.toDoubleOrNull()?.let { currentX = it }
            my?.groupValues?.get(1)?.toDoubleOrNull()?.let { currentY = it }
        } catch (_: Exception) { }

        if (!s.contains("ok", ignoreCase = true)) return

        // If there's a special latch for calibration/reset, satisfy it first
        specialAwaitingLatch?.let { latch ->
            try {
                latch.countDown()
            } catch (_: Exception) { }
            specialAwaitingLatch = null
            return
        }

        // If there's a per-line latch waiting, satisfy it
        sendAwaitingLatch?.let { latch ->
            try {
                latch.countDown()
            } catch (_: Exception) {}
            // do not set sendAwaitingLatch = null here; the sending thread will clear it after await returns
            return
        }
    }

    // -----------------------
    // BLE / scanning logic
    // -----------------------
    private fun onBluetoothButtonPressed() {
        if (bluetoothAdapter == null) {
            appendInfo("Bluetooth não disponível neste dispositivo.")
            return
        }
        if (bluetoothAdapter?.isEnabled != true) {
            appendInfo("Bluetooth está desativado. Solicitando ativação...")
            val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            enableBtLauncher.launch(intent)
            return
        }
        checkAndRequestPermissions()
    }

    private fun checkAndRequestPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            }
        } else {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }

        if (perms.isNotEmpty()) {
            appendInfo("Solicitando permissões Bluetooth...")
            permissionsLauncher.launch(perms.toTypedArray())
        } else {
            startBleScanWithChecks()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBleScanWithChecks() {
        val adapter = bluetoothAdapter
        if (adapter == null) {
            appendInfo("BluetoothAdapter é nulo.")
            return
        }
        if (!adapter.isEnabled) {
            appendInfo("Bluetooth não está ligado.")
            return
        }

        bleScanner = adapter.bluetoothLeScanner
        if (bleScanner == null) {
            appendInfo("BluetoothLeScanner não disponível.")
            return
        }

        discoveredDevices.clear()
        appendInfo("Iniciando scan BLE...")
        startScan()

        handler.postDelayed({
            stopScan()
            if (discoveredDevices.isEmpty()) {
                appendInfo("Nenhum dispositivo BLE encontrado.")
            } else {
                showDeviceSelectionDialog()
            }
        }, 2500)
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        if (isScanning) return
        val scanner = bleScanner ?: return

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        try {
            scanner.startScan(null, settings, scanCallback)
            isScanning = true
        } catch (ex: SecurityException) {
            appendInfo("Erro iniciando scan (permissão): ${ex.message}")
        } catch (ex: Exception) {
            appendInfo("Erro iniciando scan: ${ex.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        if (!isScanning) return
        val scanner = bleScanner ?: return
        try {
            scanner.stopScan(scanCallback)
        } catch (_: Exception) {
        } finally {
            isScanning = false
        }
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result?.device?.let { dev ->
                val addr = dev.address ?: return
                if (!discoveredDevices.containsKey(addr)) {
                    discoveredDevices[addr] = dev
                    val name = (dev.name ?: result.scanRecord?.deviceName ?: "<no-name>")
                    appendInfo("Encontrado: $name — $addr")
                }
            }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { onScanResult(ScanSettings.CALLBACK_TYPE_ALL_MATCHES, it) }
        }

        override fun onScanFailed(errorCode: Int) {
            appendInfo("Scan falhou: $errorCode")
        }
    }

    @SuppressLint("MissingPermission")
    private fun showDeviceSelectionDialog() {
        val list = ArrayList<String>()
        val devices = ArrayList<BluetoothDevice>()
        for ((_, dev) in discoveredDevices) {
            val name = dev.name ?: "<no-name>"
            list.add("$name — ${dev.address}")
            devices.add(dev)
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        val builder = AlertDialog.Builder(this)
            .setTitle("Escolha dispositivo (BLE)")
            .setAdapter(adapter) { dialog, which ->
                val chosen = devices[which]
                appendInfo("Tentando conectar com: ${(chosen.name ?: "<no-name>")} — ${chosen.address}")
                connectToDevice(chosen)
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { d, _ -> d.dismiss() }

        builder.show()
    }

    @SuppressLint("MissingPermission")
    private fun connectToDevice(device: BluetoothDevice) {
        closeGatt()
        try {
            bluetoothGatt = device.connectGatt(this, false, gattCallback)
        } catch (ex: SecurityException) {
            appendInfo("Permissão BLUETOOTH_CONNECT necessária para conectar: ${ex.message}")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            super.onConnectionStateChange(gatt, status, newState)
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                appendInfo("Conectado com sucesso.")
                try { gatt?.discoverServices() } catch (_: Exception) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                appendInfo("Desconectado.")
                commCharacteristic = null
                closeGatt()
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                appendInfo("Descoberta de serviços falhou.")
                return
            }

            val svc = gatt?.getService(SERVICE_UUID)
            if (svc == null) {
                appendInfo("Serviço esperado não encontrado.")
                return
            }
            val ch = svc.getCharacteristic(CHAR_UUID)
            if (ch == null) {
                appendInfo("Característica esperada não encontrada.")
                return
            }

            commCharacteristic = ch
            try {
                val okNotify = gatt?.setCharacteristicNotification(ch, true) ?: false
                if (okNotify) {
                    val descriptor = ch.getDescriptor(CLIENT_CHAR_CFG)
                    descriptor?.let {
                        it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        try {
                            gatt.writeDescriptor(it)
                        } catch (se: SecurityException) {
                            appendInfo("Permissão necessária para escrever descriptor.")
                        }
                    }
                }
                val props = ch.properties
            } catch (ex: Exception) {
                // ignorar
            }

            runOnUiThread { appendInfo("Pronto para comunicar (BLE).") }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?) {
            val bytes = characteristic?.value ?: return
            val s = try {
                String(bytes, Charsets.UTF_8).trim()
            } catch (e: Exception) {
                bytes.toString()
            }
            handleIncomingFromDevice(s)
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                appendInfo("Escrita característica falhou (status=$status).")
            }
            // We are sequential: writes are requested and then we wait for OK notifications.
            // No special action needed here except possibly to continue attempts if required.
        }

        override fun onDescriptorWrite(gatt: BluetoothGatt?, descriptor: BluetoothGattDescriptor?, status: Int) {
            // opcional
        }
    }

    private fun pauseSending() {
        if (!isSendingFile) return
        isPaused = true
        appendInfo("Envio pausado.")
    }

    private fun resumeSending() {
        if (!isSendingFile) return
        synchronized(pauseLock) {
            isPaused = false
            pauseLock.notifyAll()
        }
        appendInfo("Envio retomado.")
    }

    private fun cancelSending() {
        if (!isSendingFile) return
        isSendingFile = false
        isPaused = false
        resetRequestedDuringSend = false
        specialAwaitingLatch?.countDown()
        specialAwaitingLatch = null
        sendAwaitingLatch?.countDown()
        sendAwaitingLatch = null
        synchronized(pauseLock) { pauseLock.notifyAll() }
        appendInfo("Envio cancelado.")
    }

    private fun updateFileProgressUi() {
        runOnUiThread {
            if (pendingTotalLines > 0) {
                val remaining = pendingTotalLines - sentLinesCount
                fileProgress.text = "$remaining de $pendingTotalLines linhas"

                fileProgressBar.visibility = View.VISIBLE
                fileProgressBar.max = if (pendingTotalLines > 0) pendingTotalLines else 1
                fileProgressBar.progress = sentLinesCount
            } else {
                fileProgress.text = ""
                fileProgressBar.visibility = View.GONE
                fileProgressBar.progress = 0
            }
        }
    }

    /**
     * FILTER & SANITIZE a raw line so we only send commands Arduino accepts.
     * Returns:
     *  - a normalized string like "X10 Y5 Z0" (no trailing newline) if contains allowed tokens,
     *  - or null if nothing valid to send or if the assembled line would exceed MAX_LINE_BUFFER.
     */
    private fun filterLineForArduino(raw: String): String? {
        var i = 0
        val n = raw.length
        val out = StringBuilder()
        var hadToken = false

        // ignore comments between parentheses or starting with ';' — simple approach:
        var inPar = false
        while (i < n) {
            var c = raw[i]
            if (c == '(') {
                inPar = true
                i++
                continue
            }
            if (inPar) {
                if (c == ')') inPar = false
                i++; continue
            }
            if (c == ';') break // rest of line is comment
            // Skip whitespace
            if (c.isWhitespace()) { i++; continue }
            // If letter token
            if (c.isLetter()) {
                val up = c.uppercaseChar()
                if (!ALLOWED_CMDS.contains(up)) {
                    // unsupported command letter — skip it and its numeric argument
                    i++
                    // skip following signs/digits/decimal until next non-number/non-sign
                    while (i < n) {
                        val nc = raw[i]
                        if (nc.isLetter() || nc == '(' || nc == ';') break
                        i++
                    }
                    continue
                }
                // allowed letter: append space if not first token
                if (hadToken) out.append(' ')
                out.append(up)
                i++
                hadToken = true
                // now gather argument characters: sign, digits, dot, plus sign
                val argStart = i
                val argSb = StringBuilder()
                while (i < n) {
                    val nc = raw[i]
                    if (nc == '(' || nc == ';') break
                    if (nc.isLetter()) break
                    if (nc.isWhitespace()) { i++; continue }
                    // accept digits, +, -, ., and comma (convert to dot)
                    if (nc.isDigit() || nc == '+' || nc == '-' || nc == '.' || nc == ',') {
                        argSb.append(if (nc == ',') '.' else nc)
                        i++; continue
                    }
                    // any other char -> stop arg
                    break
                }
                if (argSb.isNotEmpty()) {
                    out.append(argSb.toString())
                }
                // check length
                if (out.toString().toByteArray(Charset.forName("UTF-8")).size >= MAX_LINE_BUFFER) {
                    // will overflow Arduino buffer if we send this token; abandon line
                    appendInfo("Linha descartada: excede ${MAX_LINE_BUFFER} bytes.")
                    return null
                }
                continue
            } else {
                // Non-letter char outside tokens: could be number (e.g., a line that starts with number) -> ignore until a letter
                i++
            }
        }

        val result = out.toString().trim()
        return if (result.isEmpty()) null else result
    }
}
