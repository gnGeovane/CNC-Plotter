package cnc.aplicativo.cncplottersender

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class SplashScreen1 : AppCompatActivity() {
    private val SPLASH_DELAY_MS = 5000L
    private val ANIM_TRIGGER_MS = 2500L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen1)

        val splashGif = findViewById<ImageView>(R.id.splashGif)

        // Carrega o GIF da pasta drawable usando Glide
        Glide.with(this)
            .asGif()
            .load(R.drawable.abertura)
            .into(splashGif)

        // TextViews que serão animados
        val byTv = findViewById<TextView>(R.id.Nomes)
        val name1 = findViewById<TextView>(R.id.nomes)
        val andTv = findViewById<TextView>(R.id.nomes2)
        val name2 = findViewById<TextView>(R.id.nomes3)

        // Inicializa estado (invisível e deslocado para baixo)
        val initialDy = dpToPx(18f) // deslocamento inicial em dp
        listOf(byTv, name1, andTv, name2).forEach { v ->
            v.alpha = 0f
            v.translationY = initialDy
            v.visibility = View.VISIBLE
        }

        // Agendar animação para começar aos 2.5s
        Handler(Looper.getMainLooper()).postDelayed({
            val baseDuration = 600L
            val stagger = 140L

            // ordem e offsets (você pode alterar a ordem como preferir)
            val views = listOf(byTv, name1, andTv, name2)
            for ((index, view) in views.withIndex()) {
                val delay = (index * stagger)
                view.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setStartDelay(delay)
                    .setDuration(baseDuration)
                    .setInterpolator(OvershootInterpolator(1.0f))
                    .start()
            }
        }, ANIM_TRIGGER_MS)

        // Muda para MainActivity após SPLASH_DELAY_MS
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, SPLASH_DELAY_MS)
    }

    private fun dpToPx(dp: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            resources.displayMetrics
        )
    }
}
